import React from 'react';

const About = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} id="about" className="py-20 md:py-32 bg-white">
      <div className="container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800 mb-4">About Us</h2>
          <p className="text-lg text-slate-600 mb-4 leading-relaxed">
            We are a passionate team dedicated to the intersection of technology and wellness. With a strong background in mobile development and user-centric design, we specialize in creating innovative digital solutions for the fitness and healthcare industries.
          </p>
          <p className="text-lg text-slate-600 leading-relaxed">
            Our goal is to build applications that are not only functional and intuitive but also genuinely improve people's lives. From wearable tech integration to AI-powered health platforms, we thrive on tackling challenges that push the boundaries of what's possible in digital well-being.
          </p>
        </div>
      </div>
    </section>
  );
});

export default About;