import React from 'react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-slate-100 py-6">
      <div className="container mx-auto px-6 text-center text-slate-500">
        <p>&copy; {new Date().getFullYear()} Softude. All Rights Reserved.</p>
        <div className="flex justify-center space-x-4 mt-2">
            <a href="https://github.com" target="_blank" rel="noopener noreferrer" className="hover:text-slate-800 transition-colors">GitHub</a>
            <span>&bull;</span>
            <a href="https://linkedin.com" target="_blank" rel="noopener noreferrer" className="hover:text-slate-800 transition-colors">LinkedIn</a>
            <span>&bull;</span>
            <a href="https://twitter.com" target="_blank" rel="noopener noreferrer" className="hover:text-slate-800 transition-colors">Twitter</a>
        </div>
      </div>
    </footer>
  );
};

export default Footer;