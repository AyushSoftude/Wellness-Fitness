
import React, { useState } from 'react';

interface HeaderProps {
  onNavigate: (section: 'about' | 'skills' | 'tech' | 'projects' | 'contact') => void;
}

const NavLink: React.FC<{
  children: React.ReactNode;
  onClick: () => void;
}> = ({ children, onClick }) => (
  <button onClick={onClick} className="text-slate-600 hover:text-red-600 transition-colors duration-300 font-medium px-3 py-2 rounded-md">
    {children}
  </button>
);

const Header: React.FC<HeaderProps> = ({ onNavigate }) => {
  const [isOpen, setIsOpen] = useState(false);

  const handleNavClick = (section: 'about' | 'skills' | 'tech' | 'projects' | 'contact') => {
    onNavigate(section);
    setIsOpen(false);
  };

  return (
    <header className="bg-white/80 backdrop-blur-md sticky top-0 z-50 shadow-sm">
      <div className="container mx-auto px-6 py-3">
        <div className="flex items-center justify-between">
          <div>
            <a href="#">
                <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASwAAABDCAMAAABQ/iesAAAAAXNSR0IArs4c6QAAAARnQU1BAACxjwv8YQUAAAAPUExURQAAABERESIiIiIiIgAAAAAAADeT3zQAAAAEdFJOUwBAgI+fn19hSjQAAAAJcEhZcwAADsMAAA7DAcdvqGQAAAdWSURBVHhe7Zxrd6M2EIZd+P8f3IET0+iBQRsbMkG965k+Jc2yJAlJtvr79+d7rO1t29406L97V2kPj72+r7+ffn2bZ9P1e1p/LgAAAC7U/S227S0f0bYBAAAA2Fq4yW0BAABA5S41DAAAgEpdahgAAACVSw0DAACg8lRDAAAAVC41DAAAgEpdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdahgAAACVpxoGAABA5aGGAQAAULnUMAAAAApdah" />
            </a>
          </div>
          <div className="hidden md:flex items-center space-x-2">
            <NavLink onClick={() => handleNavClick('about')}>About</NavLink>
            <NavLink onClick={() => handleNavClick('skills')}>Expertise</NavLink>
            <NavLink onClick={() => handleNavClick('tech')}>Stack</NavLink>
            <NavLink onClick={() => handleNavClick('projects')}>Portfolio</NavLink>
            <NavLink onClick={() => handleNavClick('contact')}>Contact</NavLink>
          </div>
          <div className="md:hidden">
            <button onClick={() => setIsOpen(!isOpen)} className="text-slate-600 hover:text-red-600">
              <svg className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                {isOpen ? (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
                ) : (
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 6h16M4 12h16M4 18h16" />
                )}
              </svg>
            </button>
          </div>
        </div>

        {isOpen && (
          <div className="md:hidden mt-4 pb-4">
            <nav className="flex flex-col space-y-2">
              <NavLink onClick={() => handleNavClick('about')}>About</NavLink>
              <NavLink onClick={() => handleNavClick('skills')}>Expertise</NavLink>
              <NavLink onClick={() => handleNavClick('tech')}>Stack</NavLink>
              <NavLink onClick={() => handleNavClick('projects')}>Portfolio</NavLink>
              <NavLink onClick={() => handleNavClick('contact')}>Contact</NavLink>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
};

// FIX: Add default export for the Header component.
export default Header;
