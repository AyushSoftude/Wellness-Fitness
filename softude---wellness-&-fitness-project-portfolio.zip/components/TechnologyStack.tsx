import React from 'react';
import { TECH_STACK } from '../constants';
import { TechStack } from '../types';

const TechStackCard: React.FC<{ stack: TechStack }> = ({ stack }) => (
    <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col">
      <div className="flex items-center mb-4">
        {stack.icon}
        <h3 className="text-xl font-semibold text-slate-800 ml-3">{stack.category}</h3>
      </div>
      <ul className="list-disc list-inside text-slate-600 space-y-2 flex-grow">
        {stack.technologies.map(tech => <li key={tech}>{tech}</li>)}
      </ul>
    </div>
  );

const TechnologyStack = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} id="tech" className="py-20 md:py-32 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800">Our Technology Stack</h2>
          <p className="text-lg text-slate-600 mt-2 max-w-3xl mx-auto">
            Leveraging modern, robust, and scalable technologies to build premier wellness solutions.
          </p>
        </div>
        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-8">
          {TECH_STACK.map((stack) => (
            <TechStackCard key={stack.category} stack={stack} />
          ))}
        </div>
      </div>
    </section>
  );
});

export default TechnologyStack;
