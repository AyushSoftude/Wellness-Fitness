import React from 'react';
import { SKILLS } from '../constants';
import { Skill } from '../types';

const SkillCard: React.FC<{ skill: Skill }> = ({ skill }) => (
  <div className="bg-white p-6 rounded-lg shadow-md hover:shadow-xl transition-shadow duration-300 flex flex-col items-center text-center">
    {skill.icon}
    <h3 className="text-lg font-semibold text-slate-800 mt-4">{skill.name}</h3>
  </div>
);

const Skills = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} id="skills" className="py-20 md:py-32 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800">Our Expertise</h2>
          <p className="text-lg text-slate-600 mt-2 max-w-2xl mx-auto">
            A blend of technical expertise and industry knowledge to deliver impactful wellness solutions.
          </p>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-3 gap-8">
          {SKILLS.map((skill) => (
            <SkillCard key={skill.name} skill={skill} />
          ))}
        </div>
      </div>
    </section>
  );
});

export default Skills;