import React from 'react';

interface HeroProps {
  onNavigate: () => void;
}

const Hero: React.FC<HeroProps> = ({ onNavigate }) => {
  return (
    <section className="bg-black text-white">
      <div className="container mx-auto px-6 py-32 md:py-48 flex flex-col items-center justify-center text-center">
        <h1 className="text-4xl md:text-6xl font-extrabold leading-tight mb-4">
          Softude
        </h1>
        <p className="text-2xl md:text-3xl font-semibold text-slate-300 mb-4">
          Pioneering Wellness & Fitness Technology
        </p>
        <p className="text-lg md:text-xl font-light text-slate-400 mb-8 max-w-3xl">
          We engineer cutting-edge digital health solutions that inspire, heal, and empower. Our expertise spans from AI-driven personal trainers to comprehensive corporate wellness platforms, building technology that transforms lives.
        </p>
        <button 
          onClick={onNavigate} 
          className="bg-red-600 hover:bg-red-700 text-white font-bold py-3 px-8 rounded-full transition-all duration-300 transform hover:scale-105 shadow-lg"
        >
          Explore Our Portfolio
        </button>
      </div>
    </section>
  );
};

export default Hero;