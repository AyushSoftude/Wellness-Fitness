import React from 'react';
import { PROJECTS } from '../constants';
import ProjectCard from './ProjectCard';

const Projects = React.forwardRef<HTMLElement>((props, ref) => {
  return (
    <section ref={ref} id="projects" className="py-20 md:py-32 bg-white">
      <div className="container mx-auto px-6">
        <div className="text-center mb-12">
          <h2 className="text-3xl md:text-4xl font-bold text-slate-800">Our Portfolio</h2>
          <p className="text-lg text-slate-600 mt-2 max-w-2xl mx-auto">
            A selection of our work in the wellness and fitness technology space.
          </p>
        </div>
        <div className="space-y-16">
          {PROJECTS.map((project) => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </div>
    </section>
  );
});

export default Projects;