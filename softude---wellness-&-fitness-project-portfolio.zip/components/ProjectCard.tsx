
import React from 'react';
import { Project } from '../types';

interface ProjectCardProps {
  project: Project;
}

const ProjectCard: React.FC<ProjectCardProps> = ({ project }) => {
  const isUpcoming = project.category === 'Upcoming Project';

  const categoryClass = isUpcoming
    ? 'bg-amber-100 text-amber-800'
    : 'bg-red-100 text-red-800';

  return (
    <div className={`bg-slate-50 p-8 rounded-xl shadow-lg transition-opacity ${isUpcoming ? 'opacity-80' : ''}`}>
      <div className="w-full">
        <span className={`inline-block ${categoryClass} text-sm font-medium px-3 py-1 rounded-full mb-3`}>
          {project.category}
        </span>
        <h3 className="text-2xl font-bold text-slate-800 mb-4">{project.title}</h3>
        <p className="text-slate-600 mb-4 leading-relaxed">{project.description}</p>
        <div className="flex flex-wrap gap-2 mb-6">
          {project.technologies.map((tech) => (
            <span key={tech} className="bg-slate-200 text-slate-700 text-xs font-semibold px-2.5 py-1 rounded-full">
              {tech}
            </span>
          ))}
        </div>
        <div className="space-y-3">
          {project.links.map((link) => {
            if (link.url === '#') {
              return (
                 <div key={link.label} className="flex items-center text-slate-500 cursor-default">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.414-1.415L11 9.586V6z" clipRule="evenodd" />
                    </svg>
                    <span>{link.label}</span>
                 </div>
              );
            }
            return (
              <a 
                key={link.url}
                href={link.url} 
                target="_blank" 
                rel="noopener noreferrer" 
                aria-label={`${link.label} for ${project.title} (opens in a new tab)`}
                className="flex items-center text-red-600 hover:text-red-700 hover:underline transition-colors duration-300 group"
              >
                 <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                  <path fillRule="evenodd" d="M12.586 4.586a2 2 0 112.828 2.828l-3 3a2 2 0 01-2.828 0 1 1 0 00-1.414 1.414 4 4 0 005.656 0l3-3a4 4 0 00-5.656-5.656l-1.5 1.5a1 1 0 101.414 1.414l1.5-1.5zm-5 5a2 2 0 012.828 0 1 1 0 101.414-1.414 4 4 0 00-5.656 0l-3 3a4 4 0 105.656 5.656l1.5-1.5a1 1 0 10-1.414-1.414l-1.5 1.5a2 2 0 11-2.828-2.828l3-3z" clipRule="evenodd" />
                </svg>
                <span>{link.label}</span>
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4 ml-1.5 text-slate-500 group-hover:text-red-700" fill="none" viewBox="0 0 24 24" stroke="currentColor" strokeWidth={2}>
                    <path strokeLinecap="round" strokeLinejoin="round" d="M10 6H6a2 2 0 00-2 2v10a2 2 0 002 2h10a2 2 0 002-2v-4M14 4h6m0 0v6m0-6L10 14" />
                </svg>
                <span className="text-xs text-slate-400 ml-2 truncate group-hover:visible invisible">{link.url}</span>
              </a>
            );
          })}
        </div>
      </div>
    </div>
  );
};

export default ProjectCard;
